﻿namespace MachineAssetManagement.Services
{
    public class MatrixFileService
    {
        private readonly string _filePath;
        private readonly Repository _repo;
        public MatrixFileService(string filePath, Repository repo)
        {
            _filePath = filePath;
            _repo = repo;
        }

        public void ReplaceFile(List<string> lines)
        {
            File.WriteAllLines(_filePath, lines);
            _repo.InvalidateCache();
        }

        public void AppendFile(List<string> lines)
        {
            File.AppendAllLines(_filePath, lines);
            _repo.InvalidateCache();
        }
    }
}

