﻿using MachineAssetManagement.Data;
using MachineAssetManagement.Models;
using MachineAssetManagement.Services;

public class MachineService : IMachineService
{
    private readonly Repository _repo;
    public MachineService(Repository repo)
    {
        _repo = repo;
    }

    public List<Machines> machines => _repo.LoadMachines();
    public List<Machines> GetAllMachines()
    {
        return  machines;
    }
    public List<string> GetAssetsByMachine(string machineName)
    {
        return machines.Where(m => m.Name.Equals(machineName, StringComparison.OrdinalIgnoreCase))
        .SelectMany(m => m.Assets.Keys)
        .Distinct()
        .ToList();

    }

    public List<string> GetMachineWithLatestAsset()
    {
        var latestAssetSeries = machines
                                .SelectMany(m => m.Assets)         
                                .GroupBy(a => a.Key)                
                                .ToDictionary(
                                g => g.Key,
                                g => g.Max(x => x.Value)        
                                );
        var machinesUsingLatestAssets = machines
                                        .Where(m =>
                                         m.Assets.All(asset =>
                                         latestAssetSeries.TryGetValue(asset.Key, out var latest)
                                         && asset.Value == latest
                                         )
                                         )
                                        .Select(m => m.Name)
                                        .Distinct()
                                        .ToList();

    return machinesUsingLatestAssets;

        
    }

    public List<string> GetMachinesByAsset(string assetName)
    {
        return machines
        .Where(m => m.Assets.Keys
        .Any(k => string.Equals(k, assetName, StringComparison.OrdinalIgnoreCase)))
        .Select(m => m.Name)
        .Distinct()
        .ToList();

    }
}
